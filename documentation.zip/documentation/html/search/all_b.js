var searchData=
[
  ['offset_0',['offset',['../class_property_house_manager.html#a9f5961818a5b68b234bacd6a78b4f454',1,'PropertyHouseManager']]],
  ['offsetplayer_1',['OffsetPlayer',['../class_player_controller.html#a14a5f7555b1b7a150b7a049a692775d9',1,'PlayerController']]],
  ['opp_2',['OPP',['../class_card.html#a6cfe3239951e772495aa0237b6f429cba47cfbb969b087ed6566bc76e431bc39d',1,'Card.OPP()'],['../class_space.html#ac609e3622d30689b7cc91d68606bb022a47cfbb969b087ed6566bc76e431bc39d',1,'Space.OPP()']]],
  ['oppcardlist_3',['oppCardList',['../class_board.html#a26bc3e58d57d2c0b44bc5c7fb31786af',1,'Board']]],
  ['orange_4',['ORANGE',['../class_property.html#aa17b5ce41491e312571dafa0c89f86cba5b6490317b6f7270bc3ab5ffd07c1f52',1,'Property']]]
];
