var searchData=
[
  ['maincamera_0',['mainCamera',['../class_camera_controller.html#a8393464679e71c7fe4f5e972e75f201e',1,'CameraController']]],
  ['menumanager_1',['menuManager',['../class_game_manager.html#a9f57a355157191239de3d93788ce31e9',1,'GameManager']]],
  ['model_2',['model',['../class_player_controller.html#a3dcbdf245e468707f46db833edfd0771',1,'PlayerController']]],
  ['moneytext_3',['moneyText',['../class_player_controller.html#a1c1a8e2a1288608f84e68275a5eda2a7',1,'PlayerController']]]
];
