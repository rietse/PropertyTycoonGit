var searchData=
[
  ['updatehouses_0',['UpdateHouses',['../class_property_house_manager.html#a13b85430f6c3e4babc20d86a9548aba9',1,'PropertyHouseManager']]],
  ['upgradeproperty_1',['UpgradeProperty',['../class_game_manager.html#a515ad8f2da05f837f2da7aca21e817d0',1,'GameManager.UpgradeProperty()'],['../class_player_controller.html#adbf645d35dae0a70415d0eb733d73e0c',1,'PlayerController.UpgradeProperty()'],['../class_property.html#ade5591b15ab0095f5e65f1363aedd972',1,'Property.UpgradeProperty()']]],
  ['usefreejailcard_2',['UseFreeJailCard',['../class_player_controller.html#ac10ba4e41fd44501b7a5c1dc5c2063ed',1,'PlayerController']]],
  ['usejailcard_3',['UseJailCard',['../class_game_manager.html#a683952dc0073489c00f1789a5cb577c1',1,'GameManager']]]
];
