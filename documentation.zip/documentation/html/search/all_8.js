var searchData=
[
  ['jail_0',['JAIL',['../class_space.html#ac609e3622d30689b7cc91d68606bb022a61bbb38a72fbfbca4cb76c6fa7bb6ec3',1,'Space']]],
  ['jailcounter_1',['jailCounter',['../class_player_controller.html#a2831e5cbd27839b873ba84b12505c323',1,'PlayerController']]],
  ['jailfine_2',['JailFine',['../class_game_manager.html#aa06a96720d9942baf8513662b765a42d',1,'GameManager.JailFine()'],['../class_player_controller.html#aaf4d2813e514e1bb5dcc12b7801aab37',1,'PlayerController.JailFine()']]],
  ['jailfreecards_3',['jailFreeCards',['../class_player_controller.html#a9151eb76b84372bd9fe114ab102cf9e8',1,'PlayerController']]],
  ['jailpopup_4',['jailPopup',['../class_game_manager.html#a7c171c30f3c581b62d007f4dd1593870',1,'GameManager']]]
];
