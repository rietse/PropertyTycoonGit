var searchData=
[
  ['degradeproperty_0',['DegradeProperty',['../class_game_manager.html#aafba67927caa9c7fd455d3ee8b7c148e',1,'GameManager.DegradeProperty()'],['../class_player_controller.html#a37ef3f9fecc313751274bd28e53c93be',1,'PlayerController.DegradeProperty()'],['../class_property.html#ae04bdc96e14180b3c15332349cc43d59',1,'Property.DegradeProperty()']]],
  ['drawcard_1',['DrawCard',['../class_board.html#a658d39032491bbe142e99e50ecbe3b60',1,'Board']]]
];
