var searchData=
[
  ['turnstate_0',['turnState',['../class_game_manager.html#a011063f509219108f49f778a6b3f755e',1,'GameManager']]],
  ['type_1',['type',['../class_card.html#a391fd02acb1b6710a7967bf8f209aca7',1,'Card.type()'],['../class_space.html#ae69b042c0ab17fb9034add0cbe667893',1,'Space.type()']]]
];
