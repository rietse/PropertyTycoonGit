var searchData=
[
  ['triggercardeffect_0',['TriggerCardEffect',['../class_game_manager.html#ad9208181f52b5f491e306d2291a1121e',1,'GameManager']]],
  ['triggerlatestcard_1',['TriggerLatestCard',['../class_board.html#af3334d9bb8619c0ce7c5d325a6113f23',1,'Board']]]
];
