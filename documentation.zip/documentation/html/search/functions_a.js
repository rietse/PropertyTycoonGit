var searchData=
[
  ['passgo_0',['PassGo',['../class_player_controller.html#a4807b9eb3fb518a38ccb867511608121',1,'PlayerController']]],
  ['payrent_1',['PayRent',['../class_player_controller.html#a2c611e4cc3bfc784f38ca04a27fa710f',1,'PlayerController']]],
  ['purchaseproperty_2',['PurchaseProperty',['../class_game_manager.html#acdc7b7ff480915264c0d0ff6f905277f',1,'GameManager.PurchaseProperty()'],['../class_player_controller.html#abc1f36d0e8a76836044d6577ef4a52c4',1,'PlayerController.PurchaseProperty()']]]
];
