var searchData=
[
  ['freeparking_0',['freeParking',['../class_game_manager.html#a5b86c64428ec7ff478c972179764ef7d',1,'GameManager']]]
];
