var searchData=
[
  ['idnum_0',['idNum',['../class_card.html#adc282376fd6953f0c46f0b0c00514439',1,'Card.idNum()'],['../class_space.html#ad4f9099d52309a2be10a00989f069c88',1,'Space.idNum()']]],
  ['injail_1',['inJail',['../class_player_controller.html#ac49c114431429e9893b06c030d58d41a',1,'PlayerController']]],
  ['isbankrupt_2',['isBankrupt',['../class_player_controller.html#a8b7f25d59de46188becb081df2ffb9ef',1,'PlayerController']]],
  ['ismortgaged_3',['isMortgaged',['../class_property.html#a024315b65b9594809fd846df0549bebe',1,'Property.isMortgaged()'],['../class_station.html#a0a0942c33d9a52f681caaa6450bbbba9',1,'Station.isMortgaged()'],['../class_utility.html#aab68ede539e3d801ea8c60111dae0ce6',1,'Utility.isMortgaged()']]]
];
