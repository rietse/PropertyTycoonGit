var searchData=
[
  ['mortgageproperty_0',['MortgageProperty',['../class_game_manager.html#a161855c2c793e6e3245fd5d137e92eee',1,'GameManager.MortgageProperty()'],['../class_player_controller.html#abef53f004fcb4e6d4da6631014b18be0',1,'PlayerController.MortgageProperty(int player, int pos)']]],
  ['move_1',['Move',['../class_player_controller.html#a6f9a33e5e761464741fc8de11d7ef289',1,'PlayerController']]],
  ['moveplayer_2',['MovePlayer',['../class_game_manager.html#a943a3c2d48df78ea00d4d700210ce357',1,'GameManager']]]
];
