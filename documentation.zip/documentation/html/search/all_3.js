var searchData=
[
  ['dblue_0',['DBLUE',['../class_property.html#aa17b5ce41491e312571dafa0c89f86cba5c2b94590b513fc8848d87caf8921080',1,'Property']]],
  ['defaultname_1',['defaultName',['../class_space.html#a40fd7fe2e83da9589cbce8f82dacaf50',1,'Space']]],
  ['degradeproperty_2',['DegradeProperty',['../class_game_manager.html#aafba67927caa9c7fd455d3ee8b7c148e',1,'GameManager.DegradeProperty()'],['../class_player_controller.html#a37ef3f9fecc313751274bd28e53c93be',1,'PlayerController.DegradeProperty()'],['../class_property.html#ae04bdc96e14180b3c15332349cc43d59',1,'Property.DegradeProperty()']]],
  ['developmentlevel_3',['developmentLevel',['../class_property.html#ac4cb3c3c117bb8da751f827948db09e6',1,'Property']]],
  ['doublescounter_4',['doublesCounter',['../class_player_controller.html#aca160d28ca033d0b1665ccb141369ecd',1,'PlayerController']]],
  ['drawcard_5',['DrawCard',['../class_board.html#a658d39032491bbe142e99e50ecbe3b60',1,'Board']]]
];
