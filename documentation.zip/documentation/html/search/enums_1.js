var searchData=
[
  ['turnstate_0',['TurnState',['../class_game_manager.html#a5f2e323ab8cdf07561895d070658dea1',1,'GameManager']]],
  ['type_1',['Type',['../class_card.html#a6cfe3239951e772495aa0237b6f429cb',1,'Card.Type()'],['../class_space.html#ac609e3622d30689b7cc91d68606bb022',1,'Space.Type()']]]
];
