var searchData=
[
  ['opp_0',['OPP',['../class_card.html#a6cfe3239951e772495aa0237b6f429cba47cfbb969b087ed6566bc76e431bc39d',1,'Card.OPP()'],['../class_space.html#ac609e3622d30689b7cc91d68606bb022a47cfbb969b087ed6566bc76e431bc39d',1,'Space.OPP()']]],
  ['orange_1',['ORANGE',['../class_property.html#aa17b5ce41491e312571dafa0c89f86cba5b6490317b6f7270bc3ab5ffd07c1f52',1,'Property']]]
];
