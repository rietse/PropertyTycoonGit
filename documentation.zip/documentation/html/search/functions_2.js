var searchData=
[
  ['checkbankrupt_0',['CheckBankrupt',['../class_game_manager.html#aab2cd9afd15b2ebd6a8b3425d257330a',1,'GameManager']]],
  ['checkdrawnew_1',['CheckDrawNew',['../class_board.html#a122c39cdd262a75b9a67799c1868e2fb',1,'Board']]],
  ['checkmonopoly_2',['CheckMonopoly',['../class_player_controller.html#a0c1223db95ffa31f4a5b4a6dd0b7628f',1,'PlayerController']]],
  ['checkspace_3',['CheckSpace',['../class_game_manager.html#a714f8dd6079c96e57258bf479c922a12',1,'GameManager']]]
];
