var searchData=
[
  ['cameracontroller_0',['cameraController',['../class_game_manager.html#a97c0edd3eee4f4b2f92cd2117d32149c',1,'GameManager']]],
  ['canreroll_1',['canReroll',['../class_player_controller.html#a197bb8e32fc6091012ead6e86af91b5f',1,'PlayerController']]],
  ['carddescription_2',['cardDescription',['../class_card.html#a91a67acaf14c15c917e5bfd46bc8cc27',1,'Card']]],
  ['cardeffects_3',['cardEffects',['../class_card.html#a4a33a594ba6f8a77f26ad416883b6bff',1,'Card']]],
  ['cardpopup_4',['cardPopup',['../class_board.html#a92c631bc3cf8b9abe82c86bc0a3e759a',1,'Board.cardPopup()'],['../class_game_manager.html#aa61b0a5215b4886d5a5a99a62aeb7a6a',1,'GameManager.cardPopup()']]],
  ['colour_5',['colour',['../class_property.html#a19c349064805d598cd96a715e2282013',1,'Property']]],
  ['currentmodel_6',['currentModel',['../class_player_controller.html#a6f90966056c6757ea81bd33debcdf4d6',1,'PlayerController']]],
  ['currentmoney_7',['currentMoney',['../class_player_controller.html#a699c4b058fe216867b05fc13d6e60029',1,'PlayerController']]],
  ['currentplayer_8',['currentPlayer',['../class_camera_controller.html#af3dca038fdadcbe5d569d1c478d50797',1,'CameraController.currentPlayer()'],['../class_game_manager.html#aa42ba1ab5ae6bb3b28d0aace203b9279',1,'GameManager.currentPlayer()']]],
  ['currentpos_9',['currentPos',['../class_player_controller.html#ac9b518c511a6df3376f89407f6d4e69a',1,'PlayerController']]]
];
