var searchData=
[
  ['offset_0',['offset',['../class_property_house_manager.html#a9f5961818a5b68b234bacd6a78b4f454',1,'PropertyHouseManager']]],
  ['oppcardlist_1',['oppCardList',['../class_board.html#a26bc3e58d57d2c0b44bc5c7fb31786af',1,'Board']]]
];
