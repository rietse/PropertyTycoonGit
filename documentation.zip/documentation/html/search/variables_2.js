var searchData=
[
  ['defaultname_0',['defaultName',['../class_space.html#a40fd7fe2e83da9589cbce8f82dacaf50',1,'Space']]],
  ['developmentlevel_1',['developmentLevel',['../class_property.html#ac4cb3c3c117bb8da751f827948db09e6',1,'Property']]],
  ['doublescounter_2',['doublesCounter',['../class_player_controller.html#aca160d28ca033d0b1665ccb141369ecd',1,'PlayerController']]]
];
