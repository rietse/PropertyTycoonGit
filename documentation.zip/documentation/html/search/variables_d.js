var searchData=
[
  ['selectedpos_0',['selectedPos',['../class_game_manager.html#aa34b378877893b9a6ad223580c94ad3a',1,'GameManager']]],
  ['spacename_1',['spaceName',['../class_space.html#a908ce962fa252a827ced65d08d5116ed',1,'Space']]],
  ['spaces_2',['spaces',['../class_board.html#a95d648a3c22fb9f61fba622392752e70',1,'Board']]],
  ['spacestates_3',['spaceStates',['../class_board.html#aa2559db5eee4419cce186dec9b2cf4eb',1,'Board']]],
  ['state_4',['state',['../class_property_house_manager.html#a74c7452e0900fa71694a954ef823250e',1,'PropertyHouseManager']]],
  ['statprice_5',['statPrice',['../class_station.html#a709e9a1e980508137440f9b8cd56cda2',1,'Station']]]
];
