var searchData=
[
  ['jailfine_0',['JailFine',['../class_game_manager.html#aa06a96720d9942baf8513662b765a42d',1,'GameManager.JailFine()'],['../class_player_controller.html#aaf4d2813e514e1bb5dcc12b7801aab37',1,'PlayerController.JailFine()']]]
];
