var searchData=
[
  ['adddoublescounter_0',['AddDoublesCounter',['../class_player_controller.html#a4abd335a2ea7fbc4066b60e8ca5781aa',1,'PlayerController']]],
  ['addjailcounter_1',['AddJailCounter',['../class_player_controller.html#aab2bfeb25a944e702c7035e9cc664df2',1,'PlayerController']]]
];
