var searchData=
[
  ['gamemanager_0',['gameManager',['../class_board.html#a9d5641d99fa94a66ccb652f8ac1dec98',1,'Board']]]
];
