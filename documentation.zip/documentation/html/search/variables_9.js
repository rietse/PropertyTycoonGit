var searchData=
[
  ['name_0',['name',['../class_player_controller.html#af5b57ee22973420c26147762343306d1',1,'PlayerController']]],
  ['noofplayers_1',['noOfPlayers',['../class_game_manager.html#a00e917d543c34319f66ee834e8c7bce0',1,'GameManager']]]
];
