var searchData=
[
  ['tax_0',['TAX',['../class_space.html#ac609e3622d30689b7cc91d68606bb022ad2fd56af1734653a658babb6422a8e40',1,'Space']]],
  ['triggercardeffect_1',['TriggerCardEffect',['../class_game_manager.html#ad9208181f52b5f491e306d2291a1121e',1,'GameManager']]],
  ['triggerlatestcard_2',['TriggerLatestCard',['../class_board.html#af3334d9bb8619c0ce7c5d325a6113f23',1,'Board']]],
  ['turnstate_3',['TurnState',['../class_game_manager.html#a5f2e323ab8cdf07561895d070658dea1',1,'GameManager']]],
  ['turnstate_4',['turnState',['../class_game_manager.html#a011063f509219108f49f778a6b3f755e',1,'GameManager']]],
  ['type_5',['Type',['../class_card.html#a6cfe3239951e772495aa0237b6f429cb',1,'Card.Type()'],['../class_space.html#ac609e3622d30689b7cc91d68606bb022',1,'Space.Type()']]],
  ['type_6',['type',['../class_card.html#a391fd02acb1b6710a7967bf8f209aca7',1,'Card.type()'],['../class_space.html#ae69b042c0ab17fb9034add0cbe667893',1,'Space.type()']]]
];
