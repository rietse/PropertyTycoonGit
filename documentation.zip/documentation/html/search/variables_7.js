var searchData=
[
  ['jailcounter_0',['jailCounter',['../class_player_controller.html#a2831e5cbd27839b873ba84b12505c323',1,'PlayerController']]],
  ['jailfreecards_1',['jailFreeCards',['../class_player_controller.html#a9151eb76b84372bd9fe114ab102cf9e8',1,'PlayerController']]],
  ['jailpopup_2',['jailPopup',['../class_game_manager.html#a7c171c30f3c581b62d007f4dd1593870',1,'GameManager']]]
];
