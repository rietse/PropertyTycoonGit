var searchData=
[
  ['name_0',['name',['../class_player_controller.html#af5b57ee22973420c26147762343306d1',1,'PlayerController']]],
  ['nextplayer_1',['NextPlayer',['../class_game_manager.html#a569093f456d460ec41e3b19ae57eccd9',1,'GameManager']]],
  ['noofplayers_2',['noOfPlayers',['../class_game_manager.html#a00e917d543c34319f66ee834e8c7bce0',1,'GameManager']]]
];
