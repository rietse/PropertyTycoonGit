var searchData=
[
  ['nextplayer_0',['NextPlayer',['../class_game_manager.html#a569093f456d460ec41e3b19ae57eccd9',1,'GameManager']]]
];
