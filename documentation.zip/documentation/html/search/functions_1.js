var searchData=
[
  ['bankrupt_0',['Bankrupt',['../class_game_manager.html#a101dd9c28e2b3bcf1680d0faacf4e293',1,'GameManager']]]
];
