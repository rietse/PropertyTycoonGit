var searchData=
[
  ['winscreen_0',['winScreen',['../class_game_manager.html#a2d7ff0d35dd9caed406f9a884e25b0f6',1,'GameManager']]]
];
