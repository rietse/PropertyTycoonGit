var searchData=
[
  ['tax_0',['TAX',['../class_space.html#ac609e3622d30689b7cc91d68606bb022ad2fd56af1734653a658babb6422a8e40',1,'Space']]]
];
